package com.trungdoan.demosecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSecurityApplicationTests {

    @Test
    void contextLoads() {
    }

}
