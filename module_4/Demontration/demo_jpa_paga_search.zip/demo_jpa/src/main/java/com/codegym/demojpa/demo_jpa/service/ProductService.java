package com.codegym.demojpa.demo_jpa.service;

import com.codegym.demojpa.demo_jpa.model.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ProductService {
    Page<Product> getAll(Pageable pageable);
    void save(Product product);
    void deleteById(Integer id);
    Product getById(Integer id);
    Page<Product> searchByName(String name, Pageable pageable);
}
