package com.codegym.demojpa.demo_jpa.controller;

import com.codegym.demojpa.demo_jpa.model.Product;
import com.codegym.demojpa.demo_jpa.service.CategoryService;
import com.codegym.demojpa.demo_jpa.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductController {

    @Autowired
    ProductService productService;

    @Autowired
    CategoryService categoryService;

    @GetMapping("")
    public ModelAndView getListProduct() {
        return new ModelAndView("list", "products", productService.getAll());
    }

    @GetMapping("/create")
    public ModelAndView getCreatePage(Model model) {
        model.addAttribute("categories", categoryService.getAll());
        return new ModelAndView("create", "product", new Product());
    }

    @PostMapping("/create")
    public String saveProduct(@ModelAttribute Product product) {
        if (product != null) {
            productService.save(product);
        }
        return "redirect:/";
    }
}
