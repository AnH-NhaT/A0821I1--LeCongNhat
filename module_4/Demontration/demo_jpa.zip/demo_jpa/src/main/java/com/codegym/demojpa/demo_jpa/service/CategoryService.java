package com.codegym.demojpa.demo_jpa.service;

import com.codegym.demojpa.demo_jpa.model.Category;
import com.codegym.demojpa.demo_jpa.model.Product;

import java.util.List;

public interface CategoryService {
    List<Category> getAll();
}
